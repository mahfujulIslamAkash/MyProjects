//
//  ViewController.swift
//  Swipe_SideBar
//
//  Created by Mahfujul Islam Akash on 25/11/18.
//  Copyright © 2018 Mahfujul Islam Akash. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var status = false
    
    @IBOutlet weak var mainLabel: UILabel!
    var list = ["Home", "Connection", "Date", "Love Time", "Logout"]
    var listImage = ["humburger_icon"]

    @IBOutlet weak var sideBarConstant: NSLayoutConstraint!
    @IBOutlet weak var myView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tabTouch(_ sender: Any) {
        status = false
        sideBarConstant.constant = 400
        UIView.animate(withDuration: 1.0, animations: {
            self.view.layoutIfNeeded()
            
        }
        )
        
    }
    @IBAction func sideBarButton(_ sender: Any) {
        if(status)
        {
            sideBarConstant.constant = 400
            UIView.animate(withDuration: 1.0, animations: {
                self.view.layoutIfNeeded()
                
            }
            )
        }
        else
        {
            sideBarConstant.constant = 100
            UIView.animate(withDuration: 1.0, animations: {
                self.view.layoutIfNeeded()
                
            }
            )
        }
        status = !status
    }
    
    @IBAction func leftSwipe(_ sender: Any) {
        status = false
        sideBarConstant.constant = 400
        UIView.animate(withDuration: 1.0, animations: {
            self.view.layoutIfNeeded()
            
        }
        )
    }
    
    @IBAction func rightSwipe(_ sender: Any) {
        status = true
        sideBarConstant.constant = 100
        UIView.animate(withDuration: 1.0, animations: {
            self.view.layoutIfNeeded()
            
        }
        )
//        status = !status
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CellTableViewCell
        cell.listItem.text = list[indexPath.row]
        cell.icon.image = UIImage(named: listImage[0])
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if(list[indexPath.row] == list[list.count - 1])
        {
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "SecondViewController") as! SecondViewController
            present(secondViewController, animated: true, completion: nil)
            secondViewController.mainLabel.text = list[indexPath.row]
        }
        else{
            mainLabel.text = list[indexPath.row]
            status = false
            sideBarConstant.constant = 400
            UIView.animate(withDuration: 0.4, animations: {
                self.view.layoutIfNeeded()
                
            }
            )
        }
        
    }
    

}
