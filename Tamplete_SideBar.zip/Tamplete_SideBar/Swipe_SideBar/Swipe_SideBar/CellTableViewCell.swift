//
//  CellTableViewCell.swift
//  Swipe_SideBar
//
//  Created by Mahfujul Islam Akash on 25/11/18.
//  Copyright © 2018 Mahfujul Islam Akash. All rights reserved.
//

import UIKit

class CellTableViewCell: UITableViewCell {

    @IBOutlet weak var listItem: UILabel!
    @IBOutlet weak var icon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
