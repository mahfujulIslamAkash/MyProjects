//
//  WebViewController.swift
//  MyBrowser
//
//  Created by Mahfuj's MacBook Pro on 2/26/18.
//  Copyright © 2018 Mahfuj's MacBook Pro. All rights reserved.
//

import UIKit

class WebViewController: UIViewController , UITextFieldDelegate{

    
    @IBOutlet weak var Text: UITextField!
    
    @IBOutlet weak var web: UIWebView!
    
    
    @IBAction func back(_ sender: UIBarButtonItem) {
        web.goBack()
    }
    @IBAction func forward(_ sender: UIBarButtonItem) {
        web.goForward()
    }
    @IBAction func stop(_ sender: UIBarButtonItem) {
        web.stopLoading()
    }
    @IBAction func reload(_ sender: UIBarButtonItem) {
        web.reload()
    }
    
    @IBAction func GO(_ sender: UIButton) {
        let addresses = URL(string : self.Text.text!)
        
        web.loadRequest(URLRequest(url : addresses!))
        Text.text = ""
    }
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        let url = URL(string : "https://www.google.com.bd/")
        web.loadRequest(URLRequest(url: url!))
        web.scalesPageToFit = true
        self.Text.delegate = self
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        let addresses = URL(string : self.Text.text!)
        
        web.loadRequest(URLRequest(url : addresses!))
        Text.text = ""
        Text.resignFirstResponder()
        return(true)
    }
    
}
