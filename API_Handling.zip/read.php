<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$database_pspitech = "psp_itech";
$tableName = "company_expenditure";

$con=mysqli_connect($host, $user, $password, $database_pspitech );
//echo $_GET["val"];  //variable thakle '' aita use hobe r na thakle "" aita use hobe
//echo "\n";
$date = $_GET["date"];
/*$Conveyance = $_GET["Conveyance"];
$Printing_Stationary = $_GET["Printing_Stationary"];
$Entertainment = $_GET["Entertainment"];
$Car_maintanace = $_GET["Car_maintanace"];
$Factory_rent = $_GET["Factory_rent"];
$Office_rent = $_GET["Office_rent"];
$Staff_salary = $_GET["Staff_salary"];
$Product_purchase = $_GET["Product_purchase"];
$Product_delivery_expense = $_GET["Product_delivery_expense"];
$Credit_card = $_GET["Credit_card"];
$Advance_payment = $_GET["Advance_payment"];
$Telephone = $_GET["Telephone"];
$Internet = $_GET["Internet"];
$Investment_withdrawal = $_GET["Investment_withdrawal"];
$Miscellaneous = $_GET["Miscellaneous"];*/



$sql_single_date = "SELECT * FROM company_expenditure where date = '$date '";
$sql_all = "SELECT * FROM company_expenditure";


function readOnDate($connection, $day)
{
	$sql = "SELECT * FROM company_expenditure where date = '$day '";
	$result = mysqli_query($connection, $sql );
	$num = mysqli_num_rows($result);

		if($num > 0)
			{
				$post_arr = array();
				$post_arr['data'] = array();
				$post_arr['code'] = "0000";
				while($row = mysqli_fetch_assoc($result))
					{

						$post_item = array
										(
										'date' => $row['Date'],
										'conveyance' => $row['Conveyance'],
										'printing_stationary' => $row['Printing_Stationary'],
										'entertainment' => $row['Entertainment'],
										'car_maintanace' => $row['Car_maintanace'],
										'factory_rent' => $row['Factory_rent'] ,
										'office_rent' => $row['Office_rent'],
										'staff_salary' => $row['Staff_salary'],
										'product_purchase'  => $row['Product_purchase'],
										'product_delivery_expense' => $row['Product_delivery_expense'],
										'credit_card' => $row['Credit_card'],
										'advance_payment' => $row['Advance_payment'],
										'telephone'  => $row['Telephone'],
										'internet' => $row['Internet'],
										'investment_withdrawal' => $row['Investment_withdrawal'],
										'miscellaneous' => $row['Miscellaneous']


										);

						array_push($post_arr['data'], $post_item);
						// array_push($post_arr['code'], "ok");
					}
					echo json_encode($post_arr);

			}

			else
			{
				$post_arr['data'] = array();
				$post_arr['code'] = "9999";
				echo json_encode($post_arr);
			}


}

readOnDate($con, $date);

?>
