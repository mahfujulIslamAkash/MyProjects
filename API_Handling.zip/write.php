<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$database_pspitech = "psp_itech";
$tableName = "company_expenditure";

$con=mysqli_connect($host, $user, $password, $database_pspitech );
//echo $_GET["val"];  //variable thakle '' aita use hobe r na thakle "" aita use hobe
//echo "\n";
$date = $_GET["date"];
$conveyance = $_GET["conveyance"];
$printingStationary = $_GET["printingStationary"];
$entertainment = $_GET["entertainment"];
$carMaintanace = $_GET["carMaintanace"];
$factoryRent = $_GET["factoryRent"];
$officeRent = $_GET["officeRent"];
$staffSalary = $_GET["staffSalary"];
$productPurchase = $_GET["productPurchase"];
$productDeliveryExpense = $_GET["productDeliveryExpense"];
$creditCard = $_GET["creditCard"];
$advancePayment = $_GET["advancePayment"];
$telephone = $_GET["telephone"];
$internet = $_GET["internet"];
$investmentWithdrawal = $_GET["investmentWithdrawal"];
$miscellaneous = $_GET["miscellaneous"];



$sql_single_date = "SELECT * FROM company_expenditure where date = '$date '";
$sql_all = "SELECT * FROM company_expenditure";


function writeOnDate($connection, $date, $conveyance=0, $printingStationary = 0,$entertainment = 0,$carMaintanace = 0,$factoryRent = 0,$officeRent = 0,$staffSalary = 0,$productPurchase = 0,$productDeliveryExpense = 0,$creditCard = 0,$advancePayment = 0,$telephone = 0,$internet = 0, $investmentWithdrawal = 0,$miscellaneous =0)
{
	//$con=mysqli_connect($host, $user, $password, $database_pspitech );
	$sql = "SELECT * FROM company_expenditure where date = '$date'";
	$result = mysqli_query($connection, $sql );
	$num = mysqli_num_rows($result);
	if($num > 0)
	{
		//data ase,update korte hobe
		//$second_sql = "UPDATE company_expenditure SET Conveyance = Conveyance +'$conveyance' where date = '$date'";
		$second_sql = "UPDATE company_expenditure SET Conveyance = Conveyance +'$conveyance',
		Printing_Stationary= Printing_Stationary+ '$printingStationary',Entertainment= Entertainment + '$entertainment',Car_maintanace= Car_maintanace + '$carMaintanace',Factory_rent= Factory_rent + '$factoryRent',Office_rent= Office_rent + '$officeRent',
		Staff_salary= Staff_salary + '$staffSalary',Product_purchase= Product_purchase + '$productPurchase',Product_delivery_expense= Product_delivery_expense + '$productDeliveryExpense',Credit_card= Credit_card +'$creditCard',Advance_payment= Advance_payment +'$advancePayment',Internet = Internet + '$internet',Telephone= Telephone +'$telephone',Investment_withdrawal=Investment_withdrawal+'$investmentWithdrawal',Miscellaneous=Miscellaneous+'$miscellaneous' WHERE date = '$date'";

	}
	else
	{
		//data nei insert korte hobe
		//$second_sql = "INSERT INTO company_expenditure (Date, Conveyance, Internet) VALUES ('$date', '$conveyance', '$internet') ";
		$second_sql = "INSERT INTO company_expenditure (date, conveyance,printing_stationary,Entertainment,Car_maintanace,Factory_rent,Office_rent,Staff_salary,Product_purchase,Product_delivery_expense,Credit_card,Advance_payment,Telephone,Internet,Investment_withdrawal,Miscellaneous) VALUES ('$date','$conveyance','$printingStationary','$entertainment','$carMaintanace','$factoryRent','$officeRent','$staffSalary','$productPurchase','$productDeliveryExpense','$creditCard','$advancePayment','$telephone','$internet','$investmentWithdrawal','$miscellaneous')";


	}
	$result = mysqli_query($connection, $second_sql );


}

writeOnDate($con, $date, $conveyance, $printingStationary ,$entertainment ,$carMaintanace ,$factoryRent ,$officeRent ,$staffSalary ,$productPurchase ,$productDeliveryExpense ,$creditCard ,$advancePayment ,$telephone ,$internet ,$investmentWithdrawal ,$miscellaneous);



?>
