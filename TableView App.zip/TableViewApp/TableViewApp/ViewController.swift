//
//  ViewController.swift
//  TableViewApp
//
//  Created by Mahfujul Islam Akash on 24/11/18.
//  Copyright © 2018 Mahfujul Islam Akash. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var names = ["Value1" , "Value2" , "Value3" , "Value4" , "Value5"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//    extension ViewController: UITableViewDelegate , UITableViewDataSource
//    {
//
//    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return names.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CellTableViewCell
        cell.name.text = names[indexPath.row]
        cell.imageField.image = UIImage(named: "flour")
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataViewController = self.storyboard?.instantiateViewController(withIdentifier: "DataViewController") as! DataViewController
        self.present(dataViewController, animated: true, completion: nil)
        dataViewController.imageField.image = UIImage(named: "flour")
        dataViewController.name.text = names[indexPath.row]
        
    }
    
}

