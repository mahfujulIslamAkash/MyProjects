//
//  DataViewController.swift
//  TableViewApp
//
//  Created by Mahfujul Islam Akash on 24/11/18.
//  Copyright © 2018 Mahfujul Islam Akash. All rights reserved.
//

import UIKit

class DataViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var inputName: UITextField!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var imageField: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    @IBAction func vote(_ sender: Any) {
        
        
    }
    


}
